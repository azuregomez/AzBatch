#!/bin/bash
echo "Hello $1"